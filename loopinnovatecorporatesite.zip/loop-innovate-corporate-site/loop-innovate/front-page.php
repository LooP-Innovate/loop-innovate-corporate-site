<?php
/**
 * Front page: composed of template-parts/front sections.
 *
 * セクション構成の意図は docs/07-information-architecture.md を参照。
 *
 * @package loop-innovate
 */

get_header();

get_template_part( 'template-parts/front/hero' );
get_template_part( 'template-parts/front/problem' );
get_template_part( 'template-parts/front/approach' );
get_template_part( 'template-parts/front/services' );
get_template_part( 'template-parts/front/stats' );
get_template_part( 'template-parts/front/cases' );
get_template_part( 'template-parts/front/news' );
get_template_part( 'template-parts/front/cta' );

get_footer();
