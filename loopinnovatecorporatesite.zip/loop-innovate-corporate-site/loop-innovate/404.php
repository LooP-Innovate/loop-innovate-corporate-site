<?php
/**
 * 404 template.
 *
 * @package loop-innovate
 */

get_header();
?>

<div class="c-section c-section--center">
	<div class="l-container l-container--narrow">
		<p class="c-section__eyebrow">404</p>
		<h1 class="c-section__title"><?php esc_html_e( 'ページが見つかりませんでした', 'loop-innovate' ); ?></h1>
		<p class="c-section__lead"><?php esc_html_e( 'URLが変更されたか、削除された可能性があります。', 'loop-innovate' ); ?></p>
		<p>
			<a class="c-btn c-btn--primary" href="<?php echo esc_url( home_url( '/' ) ); ?>"><?php esc_html_e( 'トップページへ戻る', 'loop-innovate' ); ?></a>
		</p>
	</div>
</div>

<?php
get_footer();
