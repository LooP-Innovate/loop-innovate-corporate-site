<?php
/**
 * Static page template.
 *
 * @package loop-innovate
 */

get_header();

while ( have_posts() ) :
	the_post();

	loop_page_header( get_the_title(), (string) get_the_excerpt() );
	?>
	<article <?php post_class( 'c-entry' ); ?>>
		<div class="l-container l-container--narrow">
			<div class="c-entry__content">
				<?php the_content(); ?>
			</div>
		</div>
	</article>
	<?php
endwhile;

get_template_part( 'template-parts/front/cta' );
get_footer();
