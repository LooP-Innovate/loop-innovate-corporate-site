<?php
/**
 * LOOP Innovate theme bootstrap.
 *
 * 機能は inc/ 配下のモジュールに分割する。ここには require 以外を書かない。
 *
 * @package loop-innovate
 */

declare(strict_types=1);

define( 'LOOP_THEME_VERSION', '0.1.0' );
define( 'LOOP_THEME_DIR', get_template_directory() );
define( 'LOOP_THEME_URI', get_template_directory_uri() );

foreach ( array(
	'setup',
	'assets',
	'cpt',
	'security',
	'performance',
	'seo',
	'template-tags',
) as $loop_module ) {
	require LOOP_THEME_DIR . '/inc/' . $loop_module . '.php';
}
unset( $loop_module );
