<?php
/**
 * Site header.
 *
 * @package loop-innovate
 */

?><!doctype html>
<html <?php language_attributes(); ?>>
<head>
<meta charset="<?php bloginfo( 'charset' ); ?>">
<meta name="viewport" content="width=device-width, initial-scale=1">
<?php wp_head(); ?>
</head>
<body <?php body_class(); ?>>
<?php wp_body_open(); ?>

<a class="u-skip-link" href="#main"><?php esc_html_e( '本文へスキップ', 'loop-innovate' ); ?></a>

<header class="l-header" data-header>
	<div class="l-header__inner l-container">
		<a class="l-header__logo" href="<?php echo esc_url( home_url( '/' ) ); ?>" aria-label="<?php echo esc_attr( get_bloginfo( 'name' ) . ' ' . __( 'ホーム', 'loop-innovate' ) ); ?>">
			<?php if ( has_custom_logo() ) : ?>
				<?php the_custom_logo(); ?>
			<?php else : ?>
				<span class="l-header__wordmark" aria-hidden="true">L<span class="l-header__loop">&#8734;</span>P Innovate</span>
			<?php endif; ?>
		</a>

		<nav id="site-nav" class="l-header__nav" aria-label="<?php esc_attr_e( 'メインナビゲーション', 'loop-innovate' ); ?>">
			<?php
			wp_nav_menu(
				array(
					'theme_location' => 'primary',
					'container'      => false,
					'menu_class'     => 'l-header__menu',
					'fallback_cb'    => 'loop_nav_fallback',
					'depth'          => 1,
				)
			);
			?>
			<a class="c-btn c-btn--primary l-header__cta" href="<?php echo esc_url( home_url( '/contact/' ) ); ?>"><?php esc_html_e( 'お問い合わせ', 'loop-innovate' ); ?></a>
		</nav>

		<button class="l-header__toggle" type="button" data-nav-toggle aria-expanded="false" aria-controls="site-nav">
			<span class="l-header__toggle-box" aria-hidden="true"><span class="l-header__toggle-bar"></span></span>
			<span class="u-visually-hidden"><?php esc_html_e( 'メニューを開閉する', 'loop-innovate' ); ?></span>
		</button>
	</div>
</header>

<main id="main" class="l-main">
