<?php
/**
 * Blog index (page_for_posts) and final fallback template.
 *
 * @package loop-innovate
 */

get_header();

loop_page_header(
	__( 'ブログ', 'loop-innovate' ),
	__( 'AI活用・業務改善・現場DXの実践知を発信しています。', 'loop-innovate' )
);
?>

<div class="c-section">
	<div class="l-container">
		<?php if ( have_posts() ) : ?>
			<div class="c-card-grid">
				<?php
				while ( have_posts() ) :
					the_post();
					get_template_part( 'template-parts/card', 'post' );
				endwhile;
				?>
			</div>
			<div class="c-pagination">
				<?php
				the_posts_pagination(
					array(
						'prev_text' => __( '前へ', 'loop-innovate' ),
						'next_text' => __( '次へ', 'loop-innovate' ),
					)
				);
				?>
			</div>
		<?php else : ?>
			<p><?php esc_html_e( '記事はまだありません。', 'loop-innovate' ); ?></p>
		<?php endif; ?>
	</div>
</div>

<?php
get_template_part( 'template-parts/front/cta' );
get_footer();
