<?php
/**
 * Single post / case study.
 *
 * @package loop-innovate
 */

get_header();

while ( have_posts() ) :
	the_post();
	?>
	<article <?php post_class( 'c-entry' ); ?>>
		<header class="c-page-header">
			<div class="l-container l-container--narrow">
				<?php loop_breadcrumbs(); ?>

				<?php if ( 'case_study' === get_post_type() ) : ?>
					<?php $loop_terms = get_the_terms( get_the_ID(), 'case_industry' ); ?>
					<?php if ( $loop_terms && ! is_wp_error( $loop_terms ) ) : ?>
						<p class="c-entry__tags">
							<?php foreach ( $loop_terms as $loop_term ) : ?>
								<span class="c-tag"><?php echo esc_html( $loop_term->name ); ?></span>
							<?php endforeach; ?>
						</p>
					<?php endif; ?>
				<?php else : ?>
					<?php $loop_cat = get_the_category(); ?>
					<?php if ( ! empty( $loop_cat ) ) : ?>
						<p class="c-entry__tags"><span class="c-tag"><?php echo esc_html( $loop_cat[0]->name ); ?></span></p>
					<?php endif; ?>
				<?php endif; ?>

				<h1 class="c-page-header__title"><?php the_title(); ?></h1>

				<p class="c-entry__meta">
					<time datetime="<?php echo esc_attr( (string) get_the_date( 'c' ) ); ?>"><?php echo esc_html( (string) get_the_date() ); ?></time>
				</p>
			</div>
		</header>

		<?php if ( has_post_thumbnail() ) : ?>
			<div class="l-container l-container--narrow c-entry__thumb">
				<?php the_post_thumbnail( 'large', array( 'loading' => 'eager' ) ); ?>
			</div>
		<?php endif; ?>

		<div class="l-container l-container--narrow">
			<div class="c-entry__content">
				<?php the_content(); ?>
			</div>
		</div>
	</article>
	<?php
endwhile;

get_template_part( 'template-parts/front/cta' );
get_footer();
