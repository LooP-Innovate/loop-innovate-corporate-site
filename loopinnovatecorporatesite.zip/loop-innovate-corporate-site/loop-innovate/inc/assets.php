<?php
/**
 * Asset loading with Vite manifest integration.
 *
 * 開発時: wp-config.php に define( 'LOOP_VITE_DEV', true ); を追加し `npm run dev` を起動。
 * 本番: `npm run build` の出力 (assets/dist) を manifest 経由で enqueue する。
 *
 * @package loop-innovate
 */

declare(strict_types=1);

const LOOP_VITE_ORIGIN = 'http://localhost:5173';
const LOOP_VITE_ENTRY  = 'src/scripts/main.ts';

/**
 * Whether the Vite dev server should be used.
 */
function loop_is_vite_dev(): bool {
	return defined( 'LOOP_VITE_DEV' ) && LOOP_VITE_DEV;
}

add_action( 'wp_enqueue_scripts', 'loop_enqueue_assets' );

/**
 * Enqueue fonts, styles and module scripts.
 */
function loop_enqueue_assets(): void {
	wp_enqueue_style(
		'loop-fonts',
		'https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&family=Noto+Sans+JP:wght@400;500;700&display=swap',
		array(),
		null // フォントはURL側でバージョン管理されるため.
	);

	if ( loop_is_vite_dev() ) {
		wp_enqueue_script_module( 'loop-vite-client', LOOP_VITE_ORIGIN . '/@vite/client', array(), null );
		wp_enqueue_script_module( 'loop-main', LOOP_VITE_ORIGIN . '/' . LOOP_VITE_ENTRY, array(), null );
		return;
	}

	$manifest_path = LOOP_THEME_DIR . '/assets/dist/.vite/manifest.json';
	if ( ! is_readable( $manifest_path ) ) {
		return;
	}

	$manifest = json_decode( (string) file_get_contents( $manifest_path ), true );
	$entry    = $manifest[ LOOP_VITE_ENTRY ] ?? null;
	if ( ! is_array( $entry ) ) {
		return;
	}

	foreach ( (array) ( $entry['css'] ?? array() ) as $i => $css_file ) {
		wp_enqueue_style(
			'loop-main' . ( $i > 0 ? '-' . $i : '' ),
			LOOP_THEME_URI . '/assets/dist/' . $css_file,
			array(),
			LOOP_THEME_VERSION
		);
	}

	if ( ! empty( $entry['file'] ) ) {
		wp_enqueue_script_module(
			'loop-main',
			LOOP_THEME_URI . '/assets/dist/' . $entry['file'],
			array(),
			LOOP_THEME_VERSION
		);
	}
}

add_filter( 'wp_resource_hints', 'loop_font_resource_hints', 10, 2 );

/**
 * Preconnect to Google Fonts origins.
 *
 * @param array<int, array<string, string>|string> $urls     Resource hint URLs.
 * @param string                                   $relation Relation type.
 * @return array<int, array<string, string>|string>
 */
function loop_font_resource_hints( array $urls, string $relation ): array {
	if ( 'preconnect' === $relation ) {
		$urls[] = array( 'href' => 'https://fonts.googleapis.com' );
		$urls[] = array(
			'href'        => 'https://fonts.gstatic.com',
			'crossorigin' => 'anonymous',
		);
	}
	return $urls;
}
