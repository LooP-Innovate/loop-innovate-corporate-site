<?php
/**
 * Theme setup: supports, menus, i18n.
 *
 * @package loop-innovate
 */

declare(strict_types=1);

add_action( 'after_setup_theme', 'loop_setup' );

/**
 * Register theme supports and nav menus.
 */
function loop_setup(): void {
	// 将来の多言語対応: 全文字列は翻訳関数経由で記述する.
	load_theme_textdomain( 'loop-innovate', LOOP_THEME_DIR . '/languages' );

	add_theme_support( 'title-tag' );
	add_theme_support( 'post-thumbnails' );
	add_theme_support( 'responsive-embeds' );
	add_theme_support(
		'html5',
		array( 'search-form', 'gallery', 'caption', 'style', 'script', 'navigation-widgets' )
	);
	add_theme_support(
		'custom-logo',
		array(
			'height'      => 48,
			'width'       => 200,
			'flex-width'  => true,
			'flex-height' => true,
		)
	);

	register_nav_menus(
		array(
			'primary' => __( 'メインナビゲーション', 'loop-innovate' ),
			'footer'  => __( 'フッターナビゲーション', 'loop-innovate' ),
			'legal'   => __( '法務ナビゲーション', 'loop-innovate' ),
		)
	);

	// カード用 16:9.
	add_image_size( 'loop-card', 768, 432, true );
}
