<?php
/**
 * Custom post types and taxonomies.
 *
 * @package loop-innovate
 */

declare(strict_types=1);

add_action( 'init', 'loop_register_content_types' );

/**
 * Register the case study post type and its industry taxonomy.
 */
function loop_register_content_types(): void {
	register_post_type(
		'case_study',
		array(
			'labels'       => array(
				'name'          => __( '導入事例', 'loop-innovate' ),
				'singular_name' => __( '導入事例', 'loop-innovate' ),
				'add_new_item'  => __( '導入事例を追加', 'loop-innovate' ),
				'edit_item'     => __( '導入事例を編集', 'loop-innovate' ),
			),
			'public'       => true,
			'menu_icon'    => 'dashicons-portfolio',
			'menu_position' => 5,
			'supports'     => array( 'title', 'editor', 'thumbnail', 'excerpt', 'revisions' ),
			'has_archive'  => 'cases',
			'rewrite'      => array(
				'slug'       => 'cases',
				'with_front' => false,
			),
			'show_in_rest' => true,
		)
	);

	register_taxonomy(
		'case_industry',
		'case_study',
		array(
			'labels'       => array(
				'name'          => __( '業種', 'loop-innovate' ),
				'singular_name' => __( '業種', 'loop-innovate' ),
			),
			'hierarchical' => true,
			'public'       => true,
			'rewrite'      => array(
				'slug'       => 'cases/industry',
				'with_front' => false,
			),
			'show_in_rest' => true,
		)
	);
}
