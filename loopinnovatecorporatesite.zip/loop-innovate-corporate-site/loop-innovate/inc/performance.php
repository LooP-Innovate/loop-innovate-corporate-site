<?php
/**
 * Performance: remove unused core output.
 *
 * @package loop-innovate
 */

declare(strict_types=1);

// 絵文字変換スクリプト・スタイルの削除.
remove_action( 'wp_head', 'print_emoji_detection_script', 7 );
remove_action( 'wp_print_styles', 'print_emoji_styles' );
remove_action( 'admin_print_scripts', 'print_emoji_detection_script' );
remove_action( 'admin_print_styles', 'print_emoji_styles' );
add_filter( 'emoji_svg_url', '__return_false' );

// head の不要リンク削除.
remove_action( 'wp_head', 'rsd_link' );
remove_action( 'wp_head', 'wlwmanifest_link' );
remove_action( 'wp_head', 'wp_shortlink_wp_head' );

// 日付アーカイブは使用しない（薄いページの排除）.
add_action(
	'template_redirect',
	static function (): void {
		if ( is_date() ) {
			wp_safe_redirect( home_url( '/' ), 301 );
			exit;
		}
	}
);

// コンテンツ画像へ decoding=async / 遅延読み込みは WP コアに任せる.
