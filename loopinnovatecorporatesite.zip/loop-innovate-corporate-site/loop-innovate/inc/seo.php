<?php
/**
 * SEO: meta description, OGP, JSON-LD.
 *
 * title タグは add_theme_support( 'title-tag' )、canonical・サイトマップ・RSS は WP コアに任せ、
 * ここでは不足分のみを実装する。
 *
 * @package loop-innovate
 */

declare(strict_types=1);

/**
 * Build the meta description for the current view.
 */
function loop_meta_description(): string {
	if ( is_front_page() ) {
		return __( '未来創造工房 LOOP Innovate は、介護・福祉・医療・中小企業のための AI Forward Deployed Engineering。現場を20年知るエンジニアが、業務の可視化からAIシステムの設計・実装・運用定着まで伴走します。', 'loop-innovate' );
	}
	if ( is_singular() ) {
		$excerpt = get_the_excerpt();
		if ( '' !== $excerpt ) {
			return mb_substr( wp_strip_all_tags( $excerpt ), 0, 120 );
		}
	}
	if ( is_post_type_archive( 'case_study' ) ) {
		return __( 'LOOP Innovate の導入事例。介護・福祉・医療・中小企業の現場で、AIがどのように業務を変えたかを紹介します。', 'loop-innovate' );
	}
	if ( is_home() ) {
		return __( 'AI活用・業務改善・現場DXに関する実践的な知見を発信するブログです。', 'loop-innovate' );
	}
	return '';
}

add_action( 'wp_head', 'loop_output_meta', 1 );

/**
 * Output description and OGP tags.
 */
function loop_output_meta(): void {
	$description = loop_meta_description();
	$title       = wp_get_document_title();
	$url         = is_singular() ? get_permalink() : home_url( add_query_arg( array(), $GLOBALS['wp']->request ?? '' ) );
	$type        = is_front_page() ? 'website' : 'article';

	if ( '' !== $description ) {
		printf( '<meta name="description" content="%s">' . "\n", esc_attr( $description ) );
	}

	printf( '<meta property="og:site_name" content="%s">' . "\n", esc_attr( get_bloginfo( 'name' ) ) );
	printf( '<meta property="og:title" content="%s">' . "\n", esc_attr( $title ) );
	if ( '' !== $description ) {
		printf( '<meta property="og:description" content="%s">' . "\n", esc_attr( $description ) );
	}
	printf( '<meta property="og:type" content="%s">' . "\n", esc_attr( $type ) );
	printf( '<meta property="og:url" content="%s">' . "\n", esc_url( (string) $url ) );
	printf( '<meta property="og:locale" content="ja_JP">' . "\n" );

	$image = '';
	if ( is_singular() && has_post_thumbnail() ) {
		$image = (string) get_the_post_thumbnail_url( null, 'large' );
	} elseif ( file_exists( LOOP_THEME_DIR . '/assets/img/ogp.png' ) ) {
		$image = LOOP_THEME_URI . '/assets/img/ogp.png';
	}
	if ( '' !== $image ) {
		printf( '<meta property="og:image" content="%s">' . "\n", esc_url( $image ) );
		printf( '<meta name="twitter:card" content="summary_large_image">' . "\n" );
	} else {
		printf( '<meta name="twitter:card" content="summary">' . "\n" );
	}
}

add_action( 'wp_head', 'loop_output_jsonld', 2 );

/**
 * Output Organization / WebSite structured data on the front page.
 */
function loop_output_jsonld(): void {
	if ( ! is_front_page() ) {
		return;
	}

	$data = array(
		'@context' => 'https://schema.org',
		'@graph'   => array(
			array(
				'@type'       => 'Organization',
				'@id'         => home_url( '/#organization' ),
				'name'        => get_bloginfo( 'name' ),
				'url'         => home_url( '/' ),
				'description' => loop_meta_description(),
			),
			array(
				'@type'     => 'WebSite',
				'@id'       => home_url( '/#website' ),
				'name'      => get_bloginfo( 'name' ),
				'url'       => home_url( '/' ),
				'publisher' => array( '@id' => home_url( '/#organization' ) ),
				'inLanguage' => 'ja',
			),
		),
	);

	printf(
		'<script type="application/ld+json">%s</script>' . "\n",
		wp_json_encode( $data, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES )
	);
}
