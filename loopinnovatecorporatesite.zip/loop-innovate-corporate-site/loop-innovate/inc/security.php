<?php
/**
 * Security hardening.
 *
 * サーバー側 (wp-config / ホスティング) の設定は docs/12-wordpress-architecture.md を参照。
 *
 * @package loop-innovate
 */

declare(strict_types=1);

// WordPressバージョンの秘匿.
remove_action( 'wp_head', 'wp_generator' );
add_filter( 'the_generator', '__return_empty_string' );

// XML-RPC無効化（ブルートフォース・ピンバック悪用対策）.
add_filter( 'xmlrpc_enabled', '__return_false' );
add_filter(
	'wp_headers',
	static function ( array $headers ): array {
		unset( $headers['X-Pingback'] );
		$headers['X-Content-Type-Options'] = 'nosniff';
		$headers['X-Frame-Options']        = 'SAMEORIGIN';
		$headers['Referrer-Policy']        = 'strict-origin-when-cross-origin';
		return $headers;
	}
);

// 未ログイン時の REST ユーザー列挙を防止.
add_filter(
	'rest_endpoints',
	static function ( array $endpoints ): array {
		if ( ! is_user_logged_in() ) {
			unset( $endpoints['/wp/v2/users'], $endpoints['/wp/v2/users/(?P<id>[\d]+)'] );
		}
		return $endpoints;
	}
);

// ログインエラーからユーザー名の存在を推測させない.
add_filter(
	'login_errors',
	static fn (): string => __( 'ログイン情報が正しくありません。', 'loop-innovate' )
);

// 著者アーカイブ無効化（?author=N によるユーザー名露出防止 + 薄いページ排除）.
add_action(
	'template_redirect',
	static function (): void {
		if ( is_author() ) {
			wp_safe_redirect( home_url( '/' ), 301 );
			exit;
		}
	}
);

// コメント機能はコーポレートサイトでは使用しない.
add_filter( 'comments_open', '__return_false', 20 );
add_filter( 'pings_open', '__return_false', 20 );
