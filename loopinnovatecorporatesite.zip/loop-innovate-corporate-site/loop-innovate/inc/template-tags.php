<?php
/**
 * Template display helpers.
 *
 * @package loop-innovate
 */

declare(strict_types=1);

/**
 * Render breadcrumbs. Front page renders nothing.
 */
function loop_breadcrumbs(): void {
	if ( is_front_page() ) {
		return;
	}

	/** @var array<int, array{label: string, url: string}> $items */
	$items = array(
		array(
			'label' => __( 'ホーム', 'loop-innovate' ),
			'url'   => home_url( '/' ),
		),
	);

	if ( is_singular( 'post' ) || is_home() ) {
		$posts_page = (int) get_option( 'page_for_posts' );
		if ( $posts_page > 0 ) {
			$items[] = array(
				'label' => get_the_title( $posts_page ),
				'url'   => (string) get_permalink( $posts_page ),
			);
		}
	} elseif ( is_singular( 'case_study' ) || is_tax( 'case_industry' ) ) {
		$items[] = array(
			'label' => __( '導入事例', 'loop-innovate' ),
			'url'   => (string) get_post_type_archive_link( 'case_study' ),
		);
	}

	if ( is_singular() ) {
		$current = get_the_title();
	} elseif ( is_post_type_archive() ) {
		$current = post_type_archive_title( '', false );
	} elseif ( is_tax() || is_category() || is_tag() ) {
		$current = single_term_title( '', false );
	} elseif ( is_home() ) {
		$current      = '';
		$last         = array_pop( $items );
		$current      = $last ? $last['label'] : __( 'ブログ', 'loop-innovate' );
	} elseif ( is_search() ) {
		$current = __( '検索結果', 'loop-innovate' );
	} elseif ( is_404() ) {
		$current = __( 'ページが見つかりません', 'loop-innovate' );
	} else {
		$current = wp_get_document_title();
	}

	echo '<nav class="c-breadcrumbs" aria-label="' . esc_attr__( 'パンくずリスト', 'loop-innovate' ) . '"><ol>';
	foreach ( $items as $item ) {
		printf(
			'<li><a href="%s">%s</a></li>',
			esc_url( $item['url'] ),
			esc_html( $item['label'] )
		);
	}
	printf( '<li aria-current="page">%s</li>', esc_html( (string) $current ) );
	echo '</ol></nav>';
}

/**
 * Fallback for the primary nav before a menu is assigned in wp-admin.
 */
function loop_nav_fallback(): void {
	$links = array(
		'/about/'  => __( '会社紹介', 'loop-innovate' ),
		'/ai-fde/' => __( 'AI-FDEとは', 'loop-innovate' ),
		'/services/' => __( 'サービス', 'loop-innovate' ),
		'/cases/'  => __( '導入事例', 'loop-innovate' ),
		'/blog/'   => __( 'ブログ', 'loop-innovate' ),
	);

	echo '<ul class="l-header__menu">';
	foreach ( $links as $path => $label ) {
		printf(
			'<li><a href="%s">%s</a></li>',
			esc_url( home_url( $path ) ),
			esc_html( $label )
		);
	}
	echo '</ul>';
}

/**
 * Render the shared page header (breadcrumbs + H1 + optional lead) for inner pages.
 *
 * @param string $title Page title.
 * @param string $lead  Optional lead text.
 */
function loop_page_header( string $title, string $lead = '' ): void {
	echo '<div class="c-page-header"><div class="l-container">';
	loop_breadcrumbs();
	printf( '<h1 class="c-page-header__title">%s</h1>', esc_html( $title ) );
	if ( '' !== $lead ) {
		printf( '<p class="c-page-header__lead">%s</p>', esc_html( $lead ) );
	}
	echo '</div></div>';
}
