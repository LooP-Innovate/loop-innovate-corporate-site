<?php
/**
 * Blog post card.
 *
 * @package loop-innovate
 */

?>
<article class="c-card c-card--post">
	<a class="c-card__link" href="<?php the_permalink(); ?>">
		<div class="c-card__thumb">
			<?php if ( has_post_thumbnail() ) : ?>
				<?php the_post_thumbnail( 'loop-card' ); ?>
			<?php else : ?>
				<span class="c-card__thumb-fallback" aria-hidden="true">L&#8734;P</span>
			<?php endif; ?>
		</div>
		<div class="c-card__body">
			<?php $loop_cat = get_the_category(); ?>
			<?php if ( ! empty( $loop_cat ) ) : ?>
				<span class="c-tag"><?php echo esc_html( $loop_cat[0]->name ); ?></span>
			<?php endif; ?>
			<h3 class="c-card__title"><?php the_title(); ?></h3>
			<time class="c-card__meta" datetime="<?php echo esc_attr( (string) get_the_date( 'c' ) ); ?>"><?php echo esc_html( (string) get_the_date() ); ?></time>
		</div>
	</a>
</article>
