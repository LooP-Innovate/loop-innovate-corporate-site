<?php
/**
 * Front: AI-FDE approach section.
 *
 * @package loop-innovate
 */

$loop_phases = array(
	array(
		'num'   => '01',
		'title' => __( '可視化', 'loop-innovate' ),
		'text'  => __( '現場に入り、業務フローを分解。誰が・何に・どれだけ時間を使っているかを数字にし、ボトルネックを特定します。', 'loop-innovate' ),
	),
	array(
		'num'   => '02',
		'title' => __( '設計・実装', 'loop-innovate' ),
		'text'  => __( '汎用ツールの押し付けではなく、現場の運用に合わせてAIシステムを設計・開発。小さく作り、すぐ試します。', 'loop-innovate' ),
	),
	array(
		'num'   => '03',
		'title' => __( '定着', 'loop-innovate' ),
		'text'  => __( '運用ルールづくりと教育まで伴走。「使われ続ける仕組み」になるまでがエンジニアリングだと考えます。', 'loop-innovate' ),
	),
);
?>
<section class="c-section c-section--mist">
	<div class="l-container">
		<div class="c-section__header" data-reveal>
			<p class="c-section__eyebrow"><?php esc_html_e( 'Method', 'loop-innovate' ); ?></p>
			<h2 class="c-section__title"><?php esc_html_e( 'AI-FDEという方法', 'loop-innovate' ); ?></h2>
			<p class="c-section__lead"><?php esc_html_e( '提案書を置いて帰るコンサルではなく、現場に入って作るエンジニア。3つのフェーズをループさせ、改善を止めません。', 'loop-innovate' ); ?></p>
		</div>

		<ol class="c-phases">
			<?php foreach ( $loop_phases as $loop_i => $loop_phase ) : ?>
				<li class="c-phases__item" data-reveal data-reveal-delay="<?php echo esc_attr( (string) ( $loop_i * 120 ) ); ?>">
					<span class="c-phases__num" aria-hidden="true"><?php echo esc_html( $loop_phase['num'] ); ?></span>
					<h3 class="c-phases__title"><?php echo esc_html( $loop_phase['title'] ); ?></h3>
					<p class="c-phases__text"><?php echo esc_html( $loop_phase['text'] ); ?></p>
				</li>
			<?php endforeach; ?>
		</ol>

		<p class="c-section__more" data-reveal>
			<a class="c-btn c-btn--ghost" href="<?php echo esc_url( home_url( '/ai-fde/' ) ); ?>"><?php esc_html_e( 'AI-FDEについて詳しく', 'loop-innovate' ); ?><span class="c-btn__arrow" aria-hidden="true">&rarr;</span></a>
		</p>
	</div>
</section>
