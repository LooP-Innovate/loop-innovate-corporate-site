<?php
/**
 * Front: latest blog posts.
 *
 * @package loop-innovate
 */

$loop_posts = new WP_Query(
	array(
		'post_type'           => 'post',
		'posts_per_page'      => 3,
		'no_found_rows'       => true,
		'ignore_sticky_posts' => true,
	)
);

if ( ! $loop_posts->have_posts() ) {
	return;
}
?>
<section class="c-section">
	<div class="l-container">
		<div class="c-section__header" data-reveal>
			<p class="c-section__eyebrow"><?php esc_html_e( 'Blog', 'loop-innovate' ); ?></p>
			<h2 class="c-section__title"><?php esc_html_e( 'ブログ', 'loop-innovate' ); ?></h2>
		</div>

		<div class="c-card-grid c-card-grid--3">
			<?php
			while ( $loop_posts->have_posts() ) :
				$loop_posts->the_post();
				get_template_part( 'template-parts/card', 'post' );
			endwhile;
			wp_reset_postdata();
			?>
		</div>

		<?php $loop_posts_page = (int) get_option( 'page_for_posts' ); ?>
		<?php if ( $loop_posts_page > 0 ) : ?>
			<p class="c-section__more" data-reveal>
				<a class="c-btn c-btn--ghost" href="<?php echo esc_url( (string) get_permalink( $loop_posts_page ) ); ?>"><?php esc_html_e( 'ブログ一覧へ', 'loop-innovate' ); ?><span class="c-btn__arrow" aria-hidden="true">&rarr;</span></a>
			</p>
		<?php endif; ?>
	</div>
</section>
