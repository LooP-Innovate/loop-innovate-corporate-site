<?php
/**
 * Shared CTA section (front page and inner pages).
 *
 * @package loop-innovate
 */

?>
<section class="c-cta">
	<div class="l-container c-cta__inner" data-reveal>
		<h2 class="c-cta__title"><?php esc_html_e( 'まずは、現場の課題をお聞かせください。', 'loop-innovate' ); ?></h2>
		<p class="c-cta__lead"><?php esc_html_e( '相談は無料です。営業電話は行いません。「何から相談していいか分からない」段階からで大丈夫です。', 'loop-innovate' ); ?></p>
		<p class="c-cta__action">
			<a class="c-btn c-btn--light" href="<?php echo esc_url( home_url( '/contact/' ) ); ?>"><?php esc_html_e( '無料相談を予約する', 'loop-innovate' ); ?><span class="c-btn__arrow" aria-hidden="true">&rarr;</span></a>
		</p>
	</div>
</section>
