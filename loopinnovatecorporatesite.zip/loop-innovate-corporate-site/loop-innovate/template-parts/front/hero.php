<?php
/**
 * Front: hero.
 *
 * @package loop-innovate
 */

?>
<section class="c-hero" aria-label="<?php esc_attr_e( 'メインビジュアル', 'loop-innovate' ); ?>">
	<div class="c-hero__bg" aria-hidden="true">
		<span class="c-hero__orb c-hero__orb--1"></span>
		<span class="c-hero__orb c-hero__orb--2"></span>
	</div>

	<div class="l-container c-hero__inner">
		<p class="c-hero__eyebrow">AI Forward Deployed Engineering</p>
		<h1 class="c-hero__title">
			<span class="c-hero__line"><?php esc_html_e( '現場に、', 'loop-innovate' ); ?></span><span class="c-hero__line"><?php esc_html_e( 'AIを実装する。', 'loop-innovate' ); ?></span>
		</h1>
		<p class="c-hero__lead">
			<?php esc_html_e( '介護・福祉・医療の現場で20年。社会福祉士・介護福祉士の資格を持つエンジニアが、業務の可視化からAIシステムの設計・実装・運用定着まで伴走します。', 'loop-innovate' ); ?>
		</p>
		<div class="c-hero__actions">
			<a class="c-btn c-btn--primary" href="<?php echo esc_url( home_url( '/contact/' ) ); ?>"><?php esc_html_e( '無料相談を予約する', 'loop-innovate' ); ?><span class="c-btn__arrow" aria-hidden="true">&rarr;</span></a>
			<a class="c-btn c-btn--ghost" href="<?php echo esc_url( home_url( '/services/' ) ); ?>"><?php esc_html_e( 'サービスを見る', 'loop-innovate' ); ?></a>
		</div>
	</div>
</section>
