<?php
/**
 * Front: latest case studies.
 *
 * @package loop-innovate
 */

$loop_cases = new WP_Query(
	array(
		'post_type'              => 'case_study',
		'posts_per_page'         => 3,
		'no_found_rows'          => true,
		'ignore_sticky_posts'    => true,
	)
);
?>
<section class="c-section c-section--mist">
	<div class="l-container">
		<div class="c-section__header" data-reveal>
			<p class="c-section__eyebrow"><?php esc_html_e( 'Cases', 'loop-innovate' ); ?></p>
			<h2 class="c-section__title"><?php esc_html_e( '導入事例', 'loop-innovate' ); ?></h2>
		</div>

		<?php if ( $loop_cases->have_posts() ) : ?>
			<div class="c-card-grid c-card-grid--3">
				<?php
				while ( $loop_cases->have_posts() ) :
					$loop_cases->the_post();
					get_template_part( 'template-parts/card', 'case' );
				endwhile;
				wp_reset_postdata();
				?>
			</div>
			<p class="c-section__more" data-reveal>
				<a class="c-btn c-btn--ghost" href="<?php echo esc_url( (string) get_post_type_archive_link( 'case_study' ) ); ?>"><?php esc_html_e( '事例一覧へ', 'loop-innovate' ); ?><span class="c-btn__arrow" aria-hidden="true">&rarr;</span></a>
			</p>
		<?php else : ?>
			<p data-reveal><?php esc_html_e( '事例は現在準備中です。取り組みの詳細は無料相談でお話しできます。', 'loop-innovate' ); ?></p>
		<?php endif; ?>
	</div>
</section>
