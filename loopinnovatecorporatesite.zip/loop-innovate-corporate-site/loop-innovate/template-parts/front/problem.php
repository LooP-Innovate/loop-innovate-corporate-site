<?php
/**
 * Front: problem section.
 *
 * @package loop-innovate
 */

$loop_problems = array(
	array(
		'title' => __( 'ツールを入れても、業務が変わらない', 'loop-innovate' ),
		'text'  => __( '記録ソフトもタブレットも導入した。それでも残業は減らず、紙の帳票が現場に残り続けている。', 'loop-innovate' ),
	),
	array(
		'title' => __( '現場の言葉と、ITの言葉が噛み合わない', 'loop-innovate' ),
		'text'  => __( 'ベンダーに要望を伝えても「仕様です」で終わる。加算要件や監査、多職種連携の事情が通じない。', 'loop-innovate' ),
	),
	array(
		'title' => __( '担当者任せで、定着しない', 'loop-innovate' ),
		'text'  => __( '導入して終わりの支援では、使い方は一部の人にしか広がらない。担当者が異動すれば止まってしまう。', 'loop-innovate' ),
	),
);
?>
<section class="c-section">
	<div class="l-container">
		<div class="c-section__header" data-reveal>
			<p class="c-section__eyebrow"><?php esc_html_e( 'Problem', 'loop-innovate' ); ?></p>
			<h2 class="c-section__title"><?php esc_html_e( '「導入したのに、使われない」', 'loop-innovate' ); ?></h2>
			<p class="c-section__lead"><?php esc_html_e( 'AI・ICT導入の失敗は、技術の問題ではなく「現場との距離」の問題です。', 'loop-innovate' ); ?></p>
		</div>

		<div class="c-card-grid c-card-grid--3">
			<?php foreach ( $loop_problems as $loop_i => $loop_item ) : ?>
				<div class="c-card c-card--static" data-reveal data-reveal-delay="<?php echo esc_attr( (string) ( $loop_i * 100 ) ); ?>">
					<h3 class="c-card__title"><?php echo esc_html( $loop_item['title'] ); ?></h3>
					<p class="c-card__desc"><?php echo esc_html( $loop_item['text'] ); ?></p>
				</div>
			<?php endforeach; ?>
		</div>
	</div>
</section>
