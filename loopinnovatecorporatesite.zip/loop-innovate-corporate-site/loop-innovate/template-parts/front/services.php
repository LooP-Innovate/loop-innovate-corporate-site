<?php
/**
 * Front: services section.
 *
 * @package loop-innovate
 */

$loop_services = array(
	array(
		'title' => __( 'AI導入支援・AI顧問', 'loop-innovate' ),
		'text'  => __( '月額の顧問契約で、AI活用の相談から社内展開まで継続支援。小さく始めたい組織に。', 'loop-innovate' ),
	),
	array(
		'title' => __( 'AI議事録システム', 'loop-innovate' ),
		'text'  => __( '会議・委員会・カンファレンスの録音から議事録を自動生成。作成時間を大幅に削減します。', 'loop-innovate' ),
	),
	array(
		'title' => __( '業務自動化（GAS・Google Workspace）', 'loop-innovate' ),
		'text'  => __( '転記・集計・報告などの繰り返し作業を自動化。今使っているツールのまま業務を軽くします。', 'loop-innovate' ),
	),
	array(
		'title' => __( 'AIエージェント・Dify開発', 'loop-innovate' ),
		'text'  => __( '社内文書に答えるチャットボットや、業務特化のAIエージェントを構築・運用します。', 'loop-innovate' ),
	),
	array(
		'title' => __( 'Webアプリ・ホームページ制作', 'loop-innovate' ),
		'text'  => __( '業務システムからコーポレートサイトまで。設計から運用まで一貫して開発します。', 'loop-innovate' ),
	),
	array(
		'title' => __( 'AI教育・DX推進支援', 'loop-innovate' ),
		'text'  => __( '職員向け研修・SNS運用自動化・DX計画策定。組織全体でAIを使える状態をつくります。', 'loop-innovate' ),
	),
);
?>
<section class="c-section">
	<div class="l-container">
		<div class="c-section__header" data-reveal>
			<p class="c-section__eyebrow"><?php esc_html_e( 'Services', 'loop-innovate' ); ?></p>
			<h2 class="c-section__title"><?php esc_html_e( 'サービス', 'loop-innovate' ); ?></h2>
			<p class="c-section__lead"><?php esc_html_e( '課題の大きさに合わせて、相談だけでも、開発から定着までの一気通貫でも。', 'loop-innovate' ); ?></p>
		</div>

		<div class="c-card-grid c-card-grid--3">
			<?php foreach ( $loop_services as $loop_i => $loop_service ) : ?>
				<div class="c-card c-card--static" data-reveal data-reveal-delay="<?php echo esc_attr( (string) ( ( $loop_i % 3 ) * 100 ) ); ?>">
					<h3 class="c-card__title"><?php echo esc_html( $loop_service['title'] ); ?></h3>
					<p class="c-card__desc"><?php echo esc_html( $loop_service['text'] ); ?></p>
				</div>
			<?php endforeach; ?>
		</div>

		<p class="c-section__more" data-reveal>
			<a class="c-btn c-btn--ghost" href="<?php echo esc_url( home_url( '/services/' ) ); ?>"><?php esc_html_e( 'サービス詳細・料金目安', 'loop-innovate' ); ?><span class="c-btn__arrow" aria-hidden="true">&rarr;</span></a>
		</p>
	</div>
</section>
