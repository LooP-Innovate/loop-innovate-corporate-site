<?php
/**
 * Front: stats band.
 *
 * @package loop-innovate
 */

?>
<section class="c-stats" aria-label="<?php esc_attr_e( '実績・信頼', 'loop-innovate' ); ?>">
	<div class="l-container">
		<dl class="c-stats__grid">
			<div class="c-stats__item" data-reveal>
				<dt class="c-stats__label"><?php esc_html_e( '介護・福祉・医療の現場経験', 'loop-innovate' ); ?></dt>
				<dd class="c-stats__value"><span class="c-stats__num" data-count-to="20">0</span><span class="c-stats__unit"><?php esc_html_e( '年+', 'loop-innovate' ); ?></span></dd>
			</div>
			<div class="c-stats__item" data-reveal data-reveal-delay="100">
				<dt class="c-stats__label"><?php esc_html_e( '国家資格', 'loop-innovate' ); ?></dt>
				<dd class="c-stats__value c-stats__value--text"><?php esc_html_e( '社会福祉士・介護福祉士', 'loop-innovate' ); ?></dd>
			</div>
			<div class="c-stats__item" data-reveal data-reveal-delay="200">
				<dt class="c-stats__label"><?php esc_html_e( '支援範囲', 'loop-innovate' ); ?></dt>
				<dd class="c-stats__value c-stats__value--text"><?php esc_html_e( '可視化から定着まで一気通貫', 'loop-innovate' ); ?></dd>
			</div>
		</dl>
	</div>
</section>
