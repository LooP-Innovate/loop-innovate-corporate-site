<?php
/**
 * Case study card.
 *
 * @package loop-innovate
 */

?>
<article class="c-card c-card--case">
	<a class="c-card__link" href="<?php the_permalink(); ?>">
		<div class="c-card__thumb">
			<?php if ( has_post_thumbnail() ) : ?>
				<?php the_post_thumbnail( 'loop-card' ); ?>
			<?php else : ?>
				<span class="c-card__thumb-fallback" aria-hidden="true">L&#8734;P</span>
			<?php endif; ?>
		</div>
		<div class="c-card__body">
			<?php $loop_terms = get_the_terms( get_the_ID(), 'case_industry' ); ?>
			<?php if ( $loop_terms && ! is_wp_error( $loop_terms ) ) : ?>
				<span class="c-tag"><?php echo esc_html( $loop_terms[0]->name ); ?></span>
			<?php endif; ?>
			<h3 class="c-card__title"><?php the_title(); ?></h3>
			<?php if ( has_excerpt() ) : ?>
				<p class="c-card__desc"><?php echo esc_html( wp_strip_all_tags( get_the_excerpt() ) ); ?></p>
			<?php endif; ?>
		</div>
	</a>
</article>
