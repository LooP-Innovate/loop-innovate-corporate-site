<?php
/**
 * Generic archive: case studies, taxonomies, categories.
 *
 * @package loop-innovate
 */

get_header();

if ( is_post_type_archive( 'case_study' ) || is_tax( 'case_industry' ) ) {
	$loop_title = is_tax() ? single_term_title( '', false ) : __( '導入事例', 'loop-innovate' );
	$loop_lead  = __( '介護・福祉・医療・中小企業の現場で、AIがどのように業務を変えたかを紹介します。', 'loop-innovate' );
} else {
	$loop_title = get_the_archive_title();
	$loop_lead  = '';
}

loop_page_header( (string) $loop_title, (string) $loop_lead );
?>

<div class="c-section">
	<div class="l-container">
		<?php if ( have_posts() ) : ?>
			<div class="c-card-grid">
				<?php
				while ( have_posts() ) :
					the_post();
					if ( 'case_study' === get_post_type() ) {
						get_template_part( 'template-parts/card', 'case' );
					} else {
						get_template_part( 'template-parts/card', 'post' );
					}
				endwhile;
				?>
			</div>
			<div class="c-pagination">
				<?php
				the_posts_pagination(
					array(
						'prev_text' => __( '前へ', 'loop-innovate' ),
						'next_text' => __( '次へ', 'loop-innovate' ),
					)
				);
				?>
			</div>
		<?php else : ?>
			<p><?php esc_html_e( '現在準備中です。もうしばらくお待ちください。', 'loop-innovate' ); ?></p>
		<?php endif; ?>
	</div>
</div>

<?php
get_template_part( 'template-parts/front/cta' );
get_footer();
