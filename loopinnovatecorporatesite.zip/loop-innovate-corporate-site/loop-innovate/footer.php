<?php
/**
 * Site footer.
 *
 * @package loop-innovate
 */

?>
</main>

<footer class="l-footer">
	<div class="l-container">
		<div class="l-footer__grid">
			<div class="l-footer__brand">
				<p class="l-footer__wordmark" aria-hidden="true">L<span class="l-footer__loop">&#8734;</span>P Innovate</p>
				<p class="l-footer__tagline"><?php esc_html_e( '現場に、AIを実装する。', 'loop-innovate' ); ?></p>
				<p class="l-footer__desc"><?php esc_html_e( '介護・福祉・医療・中小企業のための AI Forward Deployed Engineering。', 'loop-innovate' ); ?></p>
			</div>

			<nav class="l-footer__nav" aria-label="<?php esc_attr_e( 'フッターナビゲーション', 'loop-innovate' ); ?>">
				<?php
				wp_nav_menu(
					array(
						'theme_location' => 'footer',
						'container'      => false,
						'menu_class'     => 'l-footer__menu',
						'fallback_cb'    => 'loop_nav_fallback',
						'depth'          => 1,
					)
				);
				?>
			</nav>

			<nav class="l-footer__legal" aria-label="<?php esc_attr_e( '法務ナビゲーション', 'loop-innovate' ); ?>">
				<ul class="l-footer__menu">
					<li><a href="<?php echo esc_url( home_url( '/company/' ) ); ?>"><?php esc_html_e( '会社概要', 'loop-innovate' ); ?></a></li>
					<li><a href="<?php echo esc_url( home_url( '/privacy/' ) ); ?>"><?php esc_html_e( 'プライバシーポリシー', 'loop-innovate' ); ?></a></li>
					<li><a href="<?php echo esc_url( home_url( '/terms/' ) ); ?>"><?php esc_html_e( '利用規約', 'loop-innovate' ); ?></a></li>
					<li><a href="<?php echo esc_url( home_url( '/contact/' ) ); ?>"><?php esc_html_e( 'お問い合わせ', 'loop-innovate' ); ?></a></li>
				</ul>
			</nav>
		</div>

		<p class="l-footer__copyright">
			&copy; <?php echo esc_html( gmdate( 'Y' ) ); ?> <?php echo esc_html( get_bloginfo( 'name' ) ); ?>
		</p>
	</div>
</footer>

<?php wp_footer(); ?>
</body>
</html>
