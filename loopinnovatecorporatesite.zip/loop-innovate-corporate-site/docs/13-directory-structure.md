# ⑬ ディレクトリ設計

```
loop-innovate-corporate-site/
├── .github/workflows/ci.yml      # CI: typecheck / vite build / php -l
├── .editorconfig
├── .nvmrc                        # Node 20
├── .wp-env.json                  # ローカルWP環境定義
├── package.json                  # 依存: vite / sass / typescript のみ
├── tsconfig.json
├── vite.config.ts                # 出力: loop-innovate/assets/dist (manifest付き)
│
├── docs/                         # ①〜⑮ 設計ドキュメント（本書群）
│
├── src/                          # フロントエンドソース（ビルド対象）
│   ├── scripts/
│   │   ├── main.ts               # エントリ。SCSSもここからimport
│   │   └── modules/
│   │       ├── motion.ts         # prefers-reduced-motion 判定
│   │       ├── reveal.ts         # スクロール出現
│   │       ├── counter.ts        # 数字カウント
│   │       └── header.ts         # ヘッダー状態/モバイルナビ
│   └── styles/
│       ├── main.scss             # @use 集約
│       ├── foundation/           # _tokens / _reset / _base / _utilities
│       ├── layout/               # _header / _footer
│       └── components/           # _button / _hero / _section / _card / _stats / _cta / _entry
│
└── loop-innovate/                # ★WordPressテーマ本体（このフォルダをthemesへ配置）
    ├── style.css                 # テーマ宣言ヘッダーのみ
    ├── theme.json                # エディタをブランドトークンに制限
    ├── functions.php             # inc/ の require のみ
    ├── inc/                      # setup / assets / cpt / security / performance / seo / template-tags
    ├── header.php / footer.php
    ├── front-page.php            # トップ（template-parts/front/* を合成）
    ├── index.php                 # ブログ一覧（page_for_posts）
    ├── archive.php               # 事例ほかアーカイブ
    ├── single.php / page.php / 404.php
    ├── template-parts/
    │   ├── front/                # hero / problem / approach / services / stats / cases / news / cta
    │   ├── card-post.php
    │   └── card-case.php
    └── assets/
        └── dist/                 # Viteビルド出力（git管理外・CIで生成）
```

## 設計原則

- **テーマ = 表示、src = アセット** の分離。テーマフォルダだけをサーバーへデプロイ
- `functions.php` に処理を書かない。機能追加は `inc/` に1ファイル追加
- テンプレートの共通部品は `template-parts/` へ。`get_template_part` の第3引数で受け渡し
- CSS設計は FLOCSS簡略（foundation / layout / components）。詳細規約は `09-design-system.md`
- 将来の `/tools/` 等は `inc/cpt.php` + `archive-{cpt}.php` 追加のみで拡張可能
