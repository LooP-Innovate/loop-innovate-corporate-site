# ⑪ アニメーション設計

## 原則

1. **目的駆動** — 動きは「情報の理解を助ける」「状態を伝える」ためだけに使う。装飾で動かさない
2. **節度** — 1画面で同時に動くのは1系統まで。duration 150–800ms / easeOut系のみ
3. **性能** — `transform` / `opacity` のみアニメーション（CLS・INPを汚さない）
4. **尊重** — `prefers-reduced-motion: reduce` で全て即時表示に切替（CSS+JS両方でガード）

## インベントリ

| 名前 | 対象 | 実装 | 仕様 |
|---|---|---|---|
| Reveal | セクション/カード `[data-reveal]` | IntersectionObserver + CSS transition | opacity 0→1, translateY 24px→0, 0.8s, stagger は `data-reveal-delay` |
| Counter | 実績数字 `[data-count-to]` | rAF + IO | 1.2s easeOut。ロケール整形。reduced時は即final |
| Header状態 | `.l-header` | scroll(rAF間引き) | 8px超で背景白+blur+罫線。0.4s |
| Hover(ボタン) | `.c-btn` | CSS | 色+浮上2px+矢印4px移動。0.18s |
| Hover(カード) | `.c-card` | CSS | 浮上4px+影+罫線色。0.18s |
| モバイルナビ | `.l-header__panel` | class切替+CSS | フェード+スライド0.4s。開閉はaria同期 |
| ヒーロー背景 | `.c-hero` オーブ | CSSアニメーション | ブランドグラデーションの微速漂い(20s loop)。reduced時停止 |
| テキスト出現 | ヒーローH1 | CSS(遅延reveal) | 行単位フェードアップ。ロード直後のみ |

## ライブラリ採用基準（現状: 依存ゼロ）

上記は全て素のCSS + IntersectionObserver + rAF で実装でき、
**GSAP / Lenis / Barba.js / Three.js は初期実装では採用しない**。理由:

- バンドル増（GSAP ~70KB）に見合う表現が初期スコープに無い
- スムーススクロール(Lenis)はネイティブ挙動の上書きになり、アクセシビリティ・INPに不利
- ページ遷移(Barba)はWordPressのプラグイン互換・解析計測を複雑化する

**採用する条件**（いずれかを満たす場合のみ、個別に導入判断）:
- GSAP: SVG図解の連動シーケンス（AI-FDEループ図の工程アニメーション）を作る時
- Three.js/WebGL: ブランド刷新でヒーローに3D表現を明示的に決定した時
- Lottie: 手描き系アイコンアニメーションをデザイナーが支給した時

## 実装ファイル

- `src/scripts/modules/motion.ts` — reduced-motion判定の単一ソース
- `src/scripts/modules/reveal.ts` / `counter.ts` / `header.ts`
- CSS側: `_utilities.scss` の `[data-reveal]` とコンポーネント各所
