# ⑮ 開発ロードマップ & Git運用

## ロードマップ（目安）

| 週 | 内容 | マイルストーン |
|---|---|---|
| W1 | Phase 0-1: 基盤+トップ仕上げ | トップページ完成 |
| W2 | Phase 2: 下層ページ | 全固定ページ完成 |
| W3 | Phase 3: ブログ・事例 + 初期コンテンツ | コンテンツ入稿可能 |
| W4 | Phase 4: フォーム / Phase 5: 最適化 | 公開判定 |
| W5 | 本番公開 → Search Console / 計測開始 | 🚀 リリース v1.0.0 |
| 以降 | 週1ブログ運用 / 月次で事例追加 / 四半期でCWVレビュー | — |

## ブランチ戦略（GitHub Flow）

```
main ────●────●────●──── 常にデプロイ可能。保護ブランチ（直push禁止・PR必須）
          \feature/hero-visual
          \feature/contact-form
          \fix/header-focus-trap
```

- `feature/*` `fix/*` `docs/*` `chore/*` を main から分岐 → PR → squash merge
- develop ブランチは置かない（少人数でCIがあるため中間ブランチは管理コストのみ）
- PRテンプレート: 目的 / 変更点 / 確認手順 / スクリーンショット

## コミット規約（Conventional Commits）

```
feat: トップにstatsセクションを追加
fix: モバイルナビのフォーカストラップを修正
docs: 要件定義にフォーム仕様を追記
style: ボタンのhover遷移を調整   ← 見た目の変更（CSSのformatではない点に注意）
refactor: assets.phpのmanifest読込を関数分離
chore: viteを5.4.10へ更新
```

- 件名は日本語OK・50字以内・句点なし。本文に「なぜ」を書く

## リリース戦略

- セマンティックバージョニング: テーマ `style.css` の Version と git tag を同期
  - `v1.0.0` 公開 / `v1.x.0` ページ・機能追加 / `v1.0.x` 修正
- リリース手順: main へマージ → CI green → tag push → （将来）GitHub Actions で
  `npm run build` 済みテーマzipを生成しサーバーへ rsync/SSH デプロイ
- 本番反映前にステージング（wp-env or サーバーのステージング機能）で確認

## CI（設定済み: .github/workflows/ci.yml）

- push/PR毎: TypeScript typecheck / Vite build / 全PHPの構文チェック
- 将来追加: phpcs（WordPress Coding Standards）/ Lighthouse CI
