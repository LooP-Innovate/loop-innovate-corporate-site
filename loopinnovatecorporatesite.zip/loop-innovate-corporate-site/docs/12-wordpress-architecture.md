# ⑫ WordPress設計

## テーマ方針

- クラシックテーマ（PHPテンプレート）+ `theme.json` 最小併用
  - 理由: デザインの完全制御・パフォーマンス・保守性。エディタはブログ執筆にのみ利用し、
    theme.json でパレット/フォントサイズをブランドトークンに制限
- テーマ名 `loop-innovate` / Text Domain `loop-innovate` / 要求: WP 6.5+ / PHP 8.1+

## モジュール構成（functions.php は require のみ）

| ファイル | 責務 |
|---|---|
| `inc/setup.php` | theme supports / メニュー / 画像サイズ / textdomain |
| `inc/assets.php` | Vite manifest 連携 enqueue（開発時はdevサーバー） |
| `inc/cpt.php` | CPT `case_study` + タクソノミー `case_industry` |
| `inc/security.php` | XML-RPC無効 / バージョン秘匿 / REST ユーザー列挙防止 / 著者アーカイブ無効 / セキュリティヘッダー |
| `inc/performance.php` | 絵文字等の不要出力削除 / head掃除 |
| `inc/seo.php` | meta description / OGP / JSON-LD(Organization・WebSite) |
| `inc/template-tags.php` | パンくず / ナビフォールバック等の表示ヘルパー |

## データ設計

- 導入事例 `case_study`: 標準フィールド（タイトル/本文/抜粋/サムネ）で開始。
  課題・成果などの構造化が必要になったら **カスタムフィールドはコアの `register_post_meta` + 
  ブロックバインディングかSCF系プラグインを比較して決定**（初期はブロックパターンで代替）
- サービスは固定ページ内アンカー → 反響を見て CPT `service` 化（inc/cpt.php に追記するだけ）

## セキュリティ実装規約

- 出力: `esc_html` / `esc_attr` / `esc_url` / `wp_kses_post` を出力点で必ず適用
- 入力: フォームは Nonce（`wp_verify_nonce`）+ `sanitize_*` + サーバーサイド検証
- DB: 直クエリ禁止。必要時は `$wpdb->prepare`
- wp-config 推奨: `DISALLOW_FILE_EDIT` true / セキュリティキー設定 / DBプレフィックス変更
- ログインエラーの抽象化・XML-RPC無効・`/wp-json/wp/v2/users` 非公開化はテーマ側で実装済み

## プラグイン方針（最小主義）

| 用途 | 方針 |
|---|---|
| フォーム | Phase 4で「自作（Nonce+メール送信）」vs「Contact Form 7系」を保守性で比較。自作を第一候補 |
| SEO | テーマ内蔵で開始。運用側でtitle/desc編集が必要になったらSEO SIMPLE PACK等を検討 |
| バックアップ/セキュリティ | サーバー側(ホスティング)機能を優先 |
| キャッシュ | ホスティングのページキャッシュ優先。プラグイン多重は禁止 |

## 将来拡張の受け口

- **AI議事録アプリ**: `app.loop-innovate.com`（別アプリ）へヘッダー導線を追加するだけの疎結合。
  WP側にログイン/決済を実装しない（責務分離・PCI回避）。共通認証が必要になれば OIDC を検討
- **多言語**: 全文字列 `__()/_e()` 済み。`/en/` はマルチサイト or Polylang を比較して導入
- **REST API**: CPT は `show_in_rest` 済み。ヘッドレス化・アプリからの参照が可能

## 権限・運用

- 管理者(代表) + 投稿は「編集者」ロールで運用。管理画面URLは変更しない（曖昧なセキュリティより2FA推奨）
- 更新: マイナーは自動更新ON / メジャーはステージング確認後
