# ① 要件定義書

## 1. プロジェクト目的

未来創造工房 LOOP Innovate のコーポレートサイトを、
「AI Forward Deployed Engineering（AI-FDE）」という独自ポジションを体現する
世界水準のデザイン・実装品質で構築する。

サイトの役割は3つ。

1. **信頼の証明** — 「現場20年 × 実装力」を初回訪問の10秒で伝える
2. **リード獲得** — 経営者・施設長・ICT担当者からの問い合わせ・無料相談
3. **資産化** — ブログ・導入事例による検索流入と、将来のアプリ事業への導線

## 2. ターゲット

中小企業経営者 / 介護施設の施設長・事務長 / 医療法人・教育機関のICT担当者
（詳細は `03-persona.md`）

## 3. スコープ（初期公開時のページ構成）

| ページ | URL | テンプレート |
|---|---|---|
| トップ | `/` | front-page.php |
| 会社紹介（代表・想い） | `/about/` | page.php |
| AI-FDEとは | `/ai-fde/` | page.php |
| サービス | `/services/` | page.php（将来 CPT 化可） |
| 導入事例 一覧/詳細 | `/cases/` | archive-case_study.php / single |
| ブログ 一覧/詳細 | `/blog/` | home(index).php / single.php |
| 会社概要 | `/company/` | page.php |
| お問い合わせ | `/contact/` | page.php + フォーム |
| プライバシーポリシー | `/privacy/` | page.php |
| 利用規約 | `/terms/` | page.php |

## 4. 機能要件

- WordPress 6.5+ / 完全オリジナルテーマ（ブロックテーマではないクラシック構成 + theme.json 最小併用）
- カスタム投稿タイプ: `case_study`（導入事例）+ タクソノミー `case_industry`（業種）
- 問い合わせフォーム（Phase 4 で実装。Nonce + サーバーサイドバリデーション + reCAPTCHA/Turnstile 検討）
- OGP / JSON-LD / XMLサイトマップ（WPコア） / RSS / パンくず
- ブログはGutenbergで執筆（theme.json でブランドパレットに制限）

## 5. 非機能要件

| 項目 | 目標 |
|---|---|
| Lighthouse | Performance / A11y / Best Practices / SEO 各 95+（100を目標） |
| Core Web Vitals | LCP < 2.0s / CLS < 0.05 / INP < 200ms |
| アクセシビリティ | WCAG 2.2 AA（コントラスト・キーボード・SR・reduced-motion） |
| セキュリティ | WPコーディング規約準拠。全出力エスケープ、XML-RPC無効、ユーザー列挙防止 |
| 画像 | WebP/AVIF、width/height必須、遅延読み込み |

## 6. 将来要件（構造として考慮済み）

- **AI議事録アプリ連携**: ログイン / マイページ / ダッシュボード / Stripeサブスク。
  → 本体はサブドメイン `app.loop-innovate.com` の別アプリ（既存 ai-minutes-app）とし、
  本サイトはマーケティング + 導線に徹する。ヘッダーに「ログイン」導線を追加できる設計。
- **多言語**: `load_theme_textdomain` + 全文字列を翻訳関数経由で実装済み。将来 `/en/` を追加。
- **ナレッジベース / AIツール一覧**: CPT追加のみで拡張できる inc/ モジュール構成。

## 7. 制約・方針

- SWELL等の既製テーマ、Elementor等のページビルダーは使用しない
- プラグインは最小限（SEO・キャッシュ系は必要になった時点で個別判断）
- JSライブラリも最小限（採用基準は `11-animation.md`）
