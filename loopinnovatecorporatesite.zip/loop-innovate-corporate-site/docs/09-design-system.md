# ⑨ デザインシステム

実装は `src/styles/foundation/_tokens.scss`（CSSカスタムプロパティ）が唯一のソース。
Figmaへ移植する場合も本トークン名を維持する。プレフィックスは `--li-`。

## 1. カラートークン

| トークン | 値 | 用途 | コントラスト(白地) |
|---|---|---|---|
| `--li-ink` | #0B1220 | 見出し/主ボタン/濃色セクション背景 | 18.5:1 |
| `--li-text` | #2A3345 | 本文 | 12.4:1 |
| `--li-text-soft` | #5A6478 | 補足・キャプション | 6.6:1 |
| `--li-border` | #D7DCE5 | 罫線 | — |
| `--li-mist` | #F5F7FA | セクション交互背景 | — |
| `--li-surface` | #FFFFFF | 基本背景 | — |
| `--li-blue-600` | #1F6FD0 | リンク/アクセント/フォーカス | 4.7:1 ✔AA |
| `--li-blue-500` | #328BD3 | 図版・グラデ | 3.4:1（大サイズ/装飾のみ） |
| `--li-sky-300` | #7FCCE8 | 装飾のみ（テキスト禁止） | — |
| `--li-gradient` | 135deg #7FCCE8→#328BD3 | ∞モチーフ限定 | — |
| 濃色地の本文 | #C6CFDD on ink | 濃色セクション | 9.8:1 ✔ |

ルール: テキストに使えるのは ink / text / text-soft / blue-600 / 白系のみ。

## 2. タイポグラフィ

- 和文 `Noto Sans JP` (400/500/700) / 欧文・数字 `Inter` (400/500/600/700)
- `font-feature-settings: "palt"` は見出しのみ。本文 line-height 1.9 / 見出し 1.35

| トークン | サイズ(fluid) | 用途 |
|---|---|---|
| `--li-fs-display` | clamp(2.375rem, 1.5rem+3.9vw, 4.5rem) | H1ヒーロー |
| `--li-fs-h1` | clamp(2rem, 1.6rem+1.8vw, 3rem) | ページH1 |
| `--li-fs-h2` | clamp(1.625rem, 1.35rem+1.2vw, 2.25rem) | セクション見出し |
| `--li-fs-h3` | clamp(1.185rem, 1.1rem+0.4vw, 1.375rem) | カード見出し |
| `--li-fs-body` | 1rem (16px) | 本文 |
| `--li-fs-sm` | 0.875rem | キャプション |
| `--li-fs-eyebrow` | 0.8125rem / ls .12em / 大文字 | セクションラベル |

## 3. スペーシング（4pxベース）

`--li-sp-1〜24`: 4 8 12 16 24 32 40 48 64 80 96 128px。
セクション縦: `--li-sp-section: clamp(4rem, 2.5rem+6vw, 7.5rem)`。
コンテナ: max-width 1160px / 横パディング clamp(1.25rem, 5vw, 2.5rem)。

## 4. 形状・影

- 角丸: `--li-r-sm 6px` (ボタン) / `--li-r-md 12px` (カード) / `--li-r-lg 20px` (大パネル)
- 影: `--li-shadow-sm`(hover前) / `--li-shadow-md`(card hover)。色は ink の透過で青みを保つ
- 罫線 1px `--li-border`。影より罫線を優先（Linear的精密さ）

## 5. モーション

- `--li-dur-1 .18s`(hover) / `--li-dur-2 .4s` / `--li-dur-3 .8s`(reveal)
- `--li-ease: cubic-bezier(.22,1,.36,1)`（easeOutQuint系。減速で「上質」）
- 原則は `11-animation.md`。`prefers-reduced-motion` で全停止

## 6. ブレークポイント

`sm 480px / md 768px / lg 1024px / xl 1280px`。モバイルファースト記述。

## 7. コンポーネント規約

- 命名: FLOCSS簡略版。`l-`(layout) `c-`(component) `u-`(utility) + `is-` 状態 + `data-` JSフック
- JSフックにスタイルクラスを使わない（`data-nav-toggle` 等で分離）
- フォーカス: 全インタラクティブ要素に `:focus-visible` リング（2px blue-600 / offset 2px）
