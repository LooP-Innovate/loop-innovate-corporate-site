# ⑭ 実装計画

## フェーズ分割と完了条件

### Phase 0: 基盤（本コミットで完了）
- リポジトリ / ビルド環境（Vite+SCSS+TS） / CI / 設計ドキュメント一式
- テーマ骨格: inc/モジュール、全基本テンプレート、デザイントークン、
  トップページ8セクション（実コピー入り）、reveal/counter/headerアニメーション
- **完了条件**: `npm run build` 成功 / `php -l` 全ファイル通過 / wp-envで有効化可能

### Phase 1: トップページ仕上げ
- ヒーロー背景の作り込み（∞モチーフSVG・オーブ調整）/ 実コンテンツ差し替え
- OGP画像・ファビコン・ロゴ（`screenshot.png` 含む）
- **完了条件**: 実機（iOS/Android/PC）で表示確認、Lighthouse 90+

### Phase 2: 下層固定ページ
- about / ai-fde / services / company / privacy / terms のテンプレート+コピー
- AI-FDEループ図解（インラインSVG）
- **完了条件**: 全ページでパンくず・meta・OGPが正しい

### Phase 3: ブログ・導入事例
- 一覧/詳細の仕上げ、業種タクソノミーフィルタ、theme.jsonブロックスタイル拡充
- 初期コンテンツ: 事例2本+記事3本を入稿
- **完了条件**: エディタで崩れず執筆できる（editor-style）

### Phase 4: お問い合わせ
- フォーム実装（Nonce / sanitize / honeypot / 送信メール / 完了画面）
- スパム対策（Turnstile優先で検討）
- **完了条件**: 送信テスト・エラーパターン・SRでの操作確認

### Phase 5: 最適化・公開
- 画像WebP/AVIF化、フォントサブセット化 or self-host検討、preload調整
- 構造化データ拡充（BreadcrumbList / Article）、XMLサイトマップ確認
- 本番サーバー設定（キャッシュ・セキュリティヘッダー・SSL・リダイレクト）
- **完了条件**: Lighthouse 4項目95+ / CWV実測クリア / WCAG2.2 AA簡易監査

### Phase 6: 公開後
- Search Console / アナリティクス導入、ブログ運用開始
- 反響を見て: サービス個別ページ化、アプリ導線、英語版

## 検証手順（各Phase共通）

1. `npm run typecheck && npm run build`
2. `find loop-innovate -name '*.php' | xargs -n1 php -l`
3. wp-env でテーマ有効化 → 主要ページ目視 + キーボード操作
4. Lighthouse（モバイル）計測

## リスクと対策

| リスク | 対策 |
|---|---|
| コンテンツ（写真・事例）待ちで停滞 | プレースホルダで実装を先行し、差し替え可能な構造に |
| フォームのスパム | Phase 4でhoneypot+Turnstileを標準装備 |
| Google Fonts の遅延 | Phase 5でサブセット self-host を計測比較 |
