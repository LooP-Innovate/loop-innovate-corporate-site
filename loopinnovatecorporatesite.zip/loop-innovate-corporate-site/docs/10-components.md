# ⑩ コンポーネント設計

## Button `.c-btn`

| バリアント | 見た目 | 用途 |
|---|---|---|
| `--primary` | Ink背景/白字。hoverでblue-600へ + 微小浮上 | 主CTA |
| `--ghost` | 罫線+ink字。hoverで罫線ink化 | 副CTA |
| `--light` | 白背景/ink字 | 濃色セクション内 |

- 高さ48px(モバイル全幅) / padding 0 28px / radius `--li-r-sm`
- a要素でもbutton要素でも同スタイル。`:focus-visible`リング必須
- 矢印「→」はspanで持ち、hoverで4px平行移動（transformのみ）

## Card `.c-card`

- 共通: 白背景 / 1px border / radius md / padding sp-7。hover: border-color→blue-600系 + shadow-md + translateY(-4px)
- `card-post`（ブログ）: サムネ16:9 / カテゴリ / タイトル2行clamp / 日付
- `card-case`（事例）: 業種タグ / 課題→成果の1行 / タイトル
- `card-service`: アイコン(インラインSVG 32px) / タイトル / 説明2行
- カード全体をリンク化する場合は「見出し内aを広げる」方式（stretched link）でSR順序を保つ

## Header `.l-header`

- 固定 / 高さ72px(モバイル60px) / 透明開始 → スクロール8pxで `is-scrolled`（白+blur+下罫線）
- nav: `aria-label="メインナビゲーション"`。現在地は `aria-current="page"`
- モバイル: `data-nav-toggle` ボタン（`aria-expanded` / `aria-controls`）→ 全画面パネル。
  Escで閉じ、開時 `body.nav-open` でスクロールロック

## Footer `.l-footer`

Ink背景。3カラム（ブランド一文 / サイトマップ / 法務+SNS）→ モバイル1カラム。© は `date('Y')` 自動

## Breadcrumbs `.c-breadcrumbs`

`nav[aria-label="パンくずリスト"] > ol`。現在ページは `aria-current="page"` でリンク無し

## Stats `.c-stats`

Ink背景バンド。数値は Inter 600 / `data-count-to` でカウントアップ（reduced-motion時は即表示）

## Section 汎用 `.c-section`

- `--mist` 背景バリアント / `--ink` 濃色バリアント
- ヘッダー構造: eyebrow(`.c-section__eyebrow`) → H2 → リード
- 出現: `data-reveal` + `data-reveal-delay`（CSS transitionで実装）

## CTA `.c-cta`

Ink背景 / H2 + 補足 + primary(light)ボタン。全ページ共通で `template-parts/front/cta.php` を再利用

## Form（Phase 4）

- label必須(placeholder代用禁止) / エラーは `aria-describedby` + 色+文言
- 必須は「必須」バッジ（*だけにしない）/ autocomplete属性 / 送信中はボタンdisabled+文言変更
- Nonce + サーバーサイドバリデーション + honeypot。詳細は実装時に `12-wordpress-architecture.md` 準拠
