import { prefersReducedMotion } from './motion';

const DURATION = 1200;

/** easeOutQuint */
const ease = (t: number): number => 1 - Math.pow(1 - t, 5);

function animate(el: HTMLElement, to: number): void {
  const startTime = performance.now();

  const tick = (now: number): void => {
    const progress = Math.min((now - startTime) / DURATION, 1);
    el.textContent = Math.round(to * ease(progress)).toLocaleString('ja-JP');
    if (progress < 1) requestAnimationFrame(tick);
  };

  requestAnimationFrame(tick);
}

/**
 * [data-count-to] の数値を、ビューポート到達時にカウントアップ表示する。
 * reduced-motion 時は即座に最終値を表示。
 */
export function initCounters(): void {
  const targets = document.querySelectorAll<HTMLElement>('[data-count-to]');
  if (targets.length === 0) return;

  const showFinal = (el: HTMLElement, to: number): void => {
    el.textContent = to.toLocaleString('ja-JP');
  };

  if (prefersReducedMotion() || !('IntersectionObserver' in window)) {
    targets.forEach((el) => showFinal(el, Number(el.dataset['countTo'])));
    return;
  }

  const observer = new IntersectionObserver(
    (entries) => {
      for (const entry of entries) {
        if (!entry.isIntersecting) continue;
        const el = entry.target as HTMLElement;
        animate(el, Number(el.dataset['countTo']));
        observer.unobserve(el);
      }
    },
    { threshold: 0.5 },
  );

  targets.forEach((el) => observer.observe(el));
}
