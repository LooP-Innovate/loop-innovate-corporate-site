/**
 * ヘッダーのスクロール状態と、モバイルナビの開閉 (aria同期・Escで閉じる)。
 */
export function initHeader(): void {
  const header = document.querySelector<HTMLElement>('[data-header]');
  if (!header) return;

  // スクロール状態 (rAFで間引き)
  let ticking = false;
  const updateScrolled = (): void => {
    header.classList.toggle('is-scrolled', window.scrollY > 8);
    ticking = false;
  };
  updateScrolled();
  window.addEventListener(
    'scroll',
    () => {
      if (ticking) return;
      ticking = true;
      requestAnimationFrame(updateScrolled);
    },
    { passive: true },
  );

  // モバイルナビ
  const toggle = document.querySelector<HTMLButtonElement>('[data-nav-toggle]');
  const nav = document.getElementById('site-nav');
  if (!toggle || !nav) return;

  const setOpen = (open: boolean): void => {
    toggle.setAttribute('aria-expanded', String(open));
    document.body.classList.toggle('nav-open', open);
  };

  toggle.addEventListener('click', () => {
    setOpen(toggle.getAttribute('aria-expanded') !== 'true');
  });

  document.addEventListener('keydown', (event) => {
    if (event.key === 'Escape' && toggle.getAttribute('aria-expanded') === 'true') {
      setOpen(false);
      toggle.focus();
    }
  });

  // ナビ内リンクをクリックしたら閉じる (ページ内アンカー対応)
  nav.addEventListener('click', (event) => {
    if ((event.target as HTMLElement).closest('a')) {
      setOpen(false);
    }
  });
}
