/**
 * prefers-reduced-motion 判定の単一ソース。
 * アニメーションを追加する全モジュールはここを経由すること (docs/11-animation.md)。
 */
export const prefersReducedMotion = (): boolean =>
  window.matchMedia('(prefers-reduced-motion: reduce)').matches;
