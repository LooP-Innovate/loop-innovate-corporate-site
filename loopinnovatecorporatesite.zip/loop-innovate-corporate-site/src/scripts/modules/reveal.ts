import { prefersReducedMotion } from './motion';

/**
 * [data-reveal] 要素をスクロール到達時にフェードアップ表示する。
 * stagger は data-reveal-delay="120" (ms) をCSSカスタムプロパティへ橋渡し。
 */
export function initReveal(): void {
  const targets = document.querySelectorAll<HTMLElement>('[data-reveal]');
  if (targets.length === 0) return;

  if (prefersReducedMotion() || !('IntersectionObserver' in window)) {
    targets.forEach((el) => el.classList.add('is-inview'));
    return;
  }

  const observer = new IntersectionObserver(
    (entries) => {
      for (const entry of entries) {
        if (!entry.isIntersecting) continue;
        entry.target.classList.add('is-inview');
        observer.unobserve(entry.target);
      }
    },
    { rootMargin: '0px 0px -10% 0px', threshold: 0.1 },
  );

  targets.forEach((el) => {
    const delay = el.dataset['revealDelay'];
    if (delay) {
      el.style.setProperty('--reveal-delay', `${Number.parseInt(delay, 10)}ms`);
    }
    observer.observe(el);
  });
}
