import '../styles/main.scss';

import { initHeader } from './modules/header';
import { initReveal } from './modules/reveal';
import { initCounters } from './modules/counter';

const start = (): void => {
  initHeader();
  initReveal();
  initCounters();
};

if (document.readyState === 'loading') {
  document.addEventListener('DOMContentLoaded', start, { once: true });
} else {
  start();
}
