# LOOP Innovate コーポレートサイト

未来創造工房 L∞P Innovate（AI Forward Deployed Engineering）のコーポレートサイト。
完全オリジナルWordPressテーマ + Vite / SCSS / TypeScript による開発リポジトリです。

## 構成

```
├── docs/            設計ドキュメント（要件定義〜ロードマップ ①〜⑮）
├── loop-innovate/   WordPressテーマ本体（wp-content/themes/loop-innovate として配置）
├── src/             フロントエンドソース（SCSS / TypeScript）→ Vite が loop-innovate/assets/dist へビルド
├── vite.config.ts   ビルド設定
└── .wp-env.json     ローカルWordPress環境（@wordpress/env）
```

## クイックスタート

```bash
# 依存関係
npm install

# アセットのビルド（テーマ配下 assets/dist に出力）
npm run build

# 開発（Viteデブサーバー。wp-config.php に define('LOOP_VITE_DEV', true); を追加）
npm run dev

# ローカルWordPress（Docker必須）
npx @wordpress/env start
```

## ドキュメント

設計の全体像は [docs/](./docs/) を参照。実装に着手する前に
`01-requirements.md`（要件定義）と `14-implementation-plan.md`（実装計画）を読むこと。

## Git運用

- ブランチ: `main`（保護）+ `feature/*` / `fix/*`。PR経由でマージ。
- コミット: Conventional Commits（`feat:` `fix:` `docs:` `style:` `refactor:` `chore:`）
- 詳細: [docs/15-roadmap-and-git.md](./docs/15-roadmap-and-git.md)

## 要求環境

- WordPress 6.5+ / PHP 8.1+
- Node.js 20+
