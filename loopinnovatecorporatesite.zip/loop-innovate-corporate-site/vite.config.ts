import { defineConfig } from 'vite';

// テーマ配下 assets/dist に manifest 付きでビルドする。
// WordPress 側は inc/assets.php が manifest.json を読み enqueue する。
export default defineConfig({
  build: {
    manifest: true,
    outDir: 'loop-innovate/assets/dist',
    emptyOutDir: true,
    rollupOptions: {
      input: 'src/scripts/main.ts',
    },
  },
  server: {
    origin: 'http://localhost:5173',
    cors: true,
  },
  css: {
    preprocessorOptions: {
      scss: {
        api: 'modern',
      },
    },
  },
});
